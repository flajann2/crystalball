package com.jclark.xml.parse;

/**
 * Information about the end of a CDATA section.
 * @see com.jclark.xml.parse.base.Application#endCdataSection
 * @version $Revision: 1.1 $ $Date: 1998/06/10 09:45:10 $
 */
public interface EndCdataSectionEvent { }
