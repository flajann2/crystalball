package com.jclark.xml.tok;

/**
 * Thrown for a syntax error in parsing the prolog.
 * @see PrologParser
 * @version $Revision: 1.2 $ $Date: 1998/02/17 04:24:22 $
 */
public class PrologSyntaxException extends Exception { }
