package com.jclark.xml.tok;

/**
 * The superclass of all checked exceptions thrown by methods in
 * <code>Encoding</code>.
 *
 * @see Encoding
 * @version $Revision: 1.2 $ $Date: 1998/02/17 04:24:32 $
 */
public class TokenException extends Exception {
}
